package service;

import java.sql.SQLException;

import model.Coupon;
import model.Order;

public interface CouponService {
	public Coupon getByCode(String code) throws SQLException;
	public boolean applyCoupon(Order order, String couponcode);
}
