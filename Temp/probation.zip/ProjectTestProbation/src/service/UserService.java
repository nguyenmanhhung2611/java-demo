package service;

import java.sql.SQLException;
import java.util.List;

import model.User;

public interface UserService {
	public User getSingleUser(Integer id) throws SQLException;
	public User getUserByUsername(String username) throws SQLException;
	public List<User> getListUser(String username) throws SQLException;
	public User checkLogin(String userName, String password) throws SQLException;
}
