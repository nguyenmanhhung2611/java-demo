package service;

import java.sql.SQLException;
import java.util.List;

import model.Product;

public interface ProductService {
	public List<Product> getAllProducts() throws SQLException;
	public Product getSingleProduct(Integer id) throws SQLException;
}
