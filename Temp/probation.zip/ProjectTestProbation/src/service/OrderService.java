package service;

import java.sql.SQLException;

import model.Order;
import model.Product;

public interface OrderService {
	public int createOrder(Order order) throws SQLException; 
	public void saveOrder(Order order);
}
