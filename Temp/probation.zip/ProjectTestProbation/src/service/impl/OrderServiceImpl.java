package service.impl;

import java.sql.SQLException;
import java.util.List;

import com.sun.org.apache.bcel.internal.generic.CPInstruction;

import model.Coupon;
import model.Order;
import model.OrderDetail;
import model.Product;
import model.dao.impl.OrderDaoImpl;
import service.OrderService;

public class OrderServiceImpl implements OrderService{
	
	@Override
	public int createOrder(Order order) throws SQLException {
		OrderDaoImpl odi = new OrderDaoImpl();
		return odi.createOrder(order);
	}

	@Override
	public void saveOrder(Order order) {
		OrderService odiml = new OrderServiceImpl();
		try {
			odiml.createOrder(order);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	

}
