package service.impl;

import java.sql.SQLException;
import java.util.List;

import model.Product;
import model.dao.impl.ProductDaoImpl;
import service.ProductService;

public class ProductServiceImpl implements ProductService {

	@Override
	public List<Product> getAllProducts() throws SQLException {
		ProductDaoImpl productdao = new ProductDaoImpl();
		return productdao.getAllProducts();
	}

	@Override
	public Product getSingleProduct(Integer id) throws SQLException {
		ProductDaoImpl productdao = new ProductDaoImpl();
		return productdao.getSingleProduct(id);
	}
	
}
