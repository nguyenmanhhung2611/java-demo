package service.impl;

import java.sql.SQLException;
import java.util.List;

import model.User;
import model.dao.impl.UserDaoImpl;
import service.UserService;

public class UserServiceImpl implements UserService{

	@Override
	public User getSingleUser(Integer id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByUsername(String username) throws SQLException {
		UserDaoImpl userdao = new UserDaoImpl();
		return userdao.getUserByUsername(username);
	}

	@Override
	public List<User> getListUser(String username) throws SQLException {
		UserDaoImpl userdao = new UserDaoImpl();
		return userdao.getListUser(username);
	}

	@Override
	public User checkLogin(String userName, String password)
			throws SQLException {
		List<User> listuser = new UserDaoImpl().getListUser(userName);
		if (userName == null || listuser.isEmpty()) {
			return null;
		}
		for (User u : listuser) {
			if (u.getPassword().equals(password) && (1 == u.getIsactive())) {
				return u;
			}
		}
		return null;
	}

}
