package service.impl;

import java.sql.SQLException;

import model.Coupon;
import model.Order;
import model.dao.impl.CouponDaoImpl;
import service.CouponService;

public class CouponServiceImpl implements CouponService{

	@Override
	public Coupon getByCode(String code) throws SQLException {
		CouponDaoImpl cdimpl = new CouponDaoImpl();
		return cdimpl.getByCode(code);
	}

	@Override
	public boolean applyCoupon(Order order, String couponcode) {
		CouponService cps = new CouponServiceImpl();
		try {
			Coupon coupon = cps.getByCode(couponcode);
			if (coupon != null) {
				order.applyCoupon(coupon);
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

}
