package model;

import java.sql.Date;

public class Coupon{
	private Integer id;
	private String name;
	private String code;
	private Date starDate;
	private Date expiredDate;
	private int status;
	
	private CouponType coupontype;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public Date getStarDate() {
		return starDate;
	}
	public void setStarDate(Date starDate) {
		this.starDate = starDate;
	}
	public Date getExpiredDate() {
		return expiredDate;
	}
	public void setExpiredDate(Date expiredDate) {
		this.expiredDate = expiredDate;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public CouponType getCoupontype() {
		return coupontype;
	}
	public void setCoupontype(CouponType coupontype) {
		this.coupontype = coupontype;
	}
	
	
}
