package model;

import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import model.dao.ProductDao;
import model.dao.impl.ProductDaoImpl;

public class OrderForm {
	Order order;
	List<OrderDetailForm> items;

	public OrderForm(Order order) {
		this.order = order;
	}

	public List<OrderDetailForm> getItems() throws SQLException {
		if (items == null && order != null) {
			items = new ArrayList<OrderForm.OrderDetailForm>();
			ProductDao dao = new ProductDaoImpl();
			for (OrderDetail item : order.getItems()) {
				Product product = dao.getSingleProduct(item.getProductId());
				items.add(new OrderDetailForm(item, product));
			}
		}
		return items;
	}

	public String getTotalPaymentFormat() {
		return NumberFormat.getInstance().format(order.getTotalPayment());
	}

	public static class OrderDetailForm {
		private OrderDetail orderDetail;
		private Product product;

		public OrderDetailForm(OrderDetail orderDetail, Product product) {
			this.orderDetail = orderDetail;
			this.product = product;
		}

		public Integer getProductId() {
			return orderDetail.getProductId();
		}

		public Integer getPurchasedQuantity() {
			return orderDetail.getQuantity();
		}

		public String getProductName() {
			return product.getName();
		}

		public Double getPrice() {
			return product.getPrice();
		}

		public Double getCost() {
			return getPrice() * getPurchasedQuantity();
		}

		public String getCostFormat() {
			return NumberFormat.getInstance().format(getCost());
		}

		public String getSalePriceString() {
			return NumberFormat.getInstance().format(getPrice());
		}

	}
}
