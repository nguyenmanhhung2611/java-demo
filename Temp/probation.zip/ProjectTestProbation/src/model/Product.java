package model;

import java.sql.Date;
import java.text.NumberFormat;

public class Product {
	private int id;
	private String name;
	private String codeproduct;
	private int quantity;
	private double price;
	private Date lastUpdate;
	private User user;
	public Product(){}
	
	public Product(int id, String name, String codeproduct, int quantity,
			double price, Date lastUpdate) {
		super();
		this.id = id;
		this.name = name;
		this.codeproduct = codeproduct;
		this.quantity = quantity;
		this.price = price;
		this.lastUpdate = lastUpdate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCodeproduct() {
		return codeproduct;
	}

	public void setCodeproduct(String codeproduct) {
		this.codeproduct = codeproduct;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Date getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(Date lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public String getSalePriceString() {
		return NumberFormat.getInstance().format(this.price);
	}
}
