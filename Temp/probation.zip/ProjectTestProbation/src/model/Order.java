package model;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Order {
	private List<OrderDetail> items;
	private Double totalPayment;
	private Float discount = 0F;
	private Integer userId;
	private String addressInfo;
	private Integer couponId;

	public List<OrderDetail> getItems() {
		return items;
	}

	// contructor
	public Order() {
		items = new ArrayList<OrderDetail>();
	}

	public void addItem(Product product, Integer quantity) throws Exception {
		OrderDetail tmpItem = null;
		Integer productId = product.getId();
		for (OrderDetail item : items) {
			if (item.getProductId() == productId) {
				tmpItem = item;
			}
		}

		if (tmpItem != null) {
			Integer purchasedQuantity = tmpItem.getQuantity() + quantity;
			if (!checkProductStock(product, purchasedQuantity)) {
				throw new Exception(
						"Can not sale the product because out of stock");
			}
			tmpItem.setQuantity(purchasedQuantity);
			tmpItem.setProductPrice(product.getPrice());
		} else {
			Integer purchasedQuantity = quantity;
			if (!checkProductStock(product, purchasedQuantity)) {
				throw new Exception(
						"Can not sale the product because out of stock");
			}
			items.add(new OrderDetail(productId, purchasedQuantity, product.getPrice()));
		}
		refreshOrder();
	}

	protected void refreshOrder() {
		calculateTotalPayment();
	}

	protected void calculateTotalPayment() {
		Double totalCost = 0.0;
		for (OrderDetail item : getItems()) {
			totalCost += item.getQuantity() * item.getProductPrice();
		}
		totalPayment = totalCost * ((100 - getDiscount()) / 100);
	}
	
	// check coupon
		public void applyCoupon(Coupon coupon) {
			if (coupon.getId() != null && coupon.getId() > 0) {
				this.couponId = coupon.getId();
				this.setDiscount(coupon.getCoupontype().getDiscount());
				refreshOrder();
			}
		}


	private boolean checkProductStock(Product product, Integer purchasedQuantity)
			throws SQLException {
		return product.getQuantity() >= purchasedQuantity;
	}

	public void setItems(List<OrderDetail> items) {
		this.items = items;
	}

	public Float getDiscount() {
		return discount;
	}

	public void setDiscount(Float discount) {
		this.discount = discount;
	}

	public Double getTotalPayment() {
		return totalPayment;
	}

	public void setTotalPayment(Double totalPayment) {
		this.totalPayment = totalPayment;
	}

	public Integer getCouponId() {
		return couponId;
	}

	
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getAddressInfo() {
		return addressInfo;
	}

	public void setAddressInfo(String addressInfo) {
		this.addressInfo = addressInfo;
	}
}
