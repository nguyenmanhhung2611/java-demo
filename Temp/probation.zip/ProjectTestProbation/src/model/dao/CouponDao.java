package model.dao;

import java.sql.SQLException;

import model.Coupon;

public interface CouponDao {
	/*get code coupon*/
	public Coupon getByCode(String code) throws SQLException;
}
