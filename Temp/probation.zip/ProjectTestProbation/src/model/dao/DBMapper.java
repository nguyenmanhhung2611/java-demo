package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface DBMapper<T> {
	//Mapper 
	T doMapping(ResultSet rs) throws SQLException;
}
