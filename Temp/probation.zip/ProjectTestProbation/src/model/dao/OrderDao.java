package model.dao;

import java.sql.SQLException;
import java.util.List;

import model.Order;

public interface OrderDao {
	
	//insert order and order detail 
	public int createOrder(Order order) throws SQLException; 
//	public List<OrderDetailForm> getItems() throws SQLException;

}
