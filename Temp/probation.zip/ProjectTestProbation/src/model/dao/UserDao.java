package model.dao;

import java.sql.SQLException;
import java.util.List;

import model.User;

public interface UserDao {
	
	public User getSingleUser(Integer id) throws SQLException;
	//get user by name
	public User getUserByUsername(String username) throws SQLException;
	//get list user
	public List<User> getListUser(String username) throws SQLException;
}
