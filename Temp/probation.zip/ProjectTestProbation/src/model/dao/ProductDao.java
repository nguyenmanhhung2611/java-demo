package model.dao;

import java.sql.SQLException;
import java.util.List;

import model.Product;

public interface ProductDao{
	
	//get list product
	public List<Product> getAllProducts() throws SQLException;
	//get one product by id
	public Product getSingleProduct(Integer id) throws SQLException;
	
}
