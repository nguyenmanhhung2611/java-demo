package model.dao.impl;

import java.sql.SQLException;
import java.util.List;

import model.Product;
import model.dao.ProductDao;

public class ProductDaoImpl extends AbstractDao implements ProductDao{

	@Override
	public List<Product> getAllProducts() throws SQLException {
		String sql = "SELECT * FROM tbl_product";
		ProductMapper mapper = new ProductMapper();
		List<Product> allProducts = getList(mapper, sql);
		return allProducts;
	}

	@Override
	public Product getSingleProduct(Integer id) throws SQLException {
		String sql = "SELECT * FROM tbl_product where id = ?";
		ProductMapper mapper = new ProductMapper();
		Object paras[] = { id };
		return getSingleObject(mapper, sql, paras);
	}

}
