package model.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import model.Coupon;
import model.CouponType;
import model.dao.DBMapper;

public class CouponMapper implements DBMapper<Coupon>{

	@Override
	public Coupon doMapping(ResultSet rs) throws SQLException {
		
		// 2 table coupon and coupon type
		CouponType ct = new CouponType();
		ct.setDiscount(rs.getFloat("coupon_type_discount"));
		ct.setId(rs.getInt("coupon_type_id"));
		Coupon c = new Coupon();
		// get column in table coupon
		c.setName(rs.getString("coupon_name"));
		c.setCode(rs.getString("coupon_code"));
		c.setStarDate(rs.getDate("coupon_start_date"));
		c.setId(rs.getInt("coupon_id"));
		c.setExpiredDate(rs.getDate("coupon_expired_date"));
		c.setStatus(rs.getInt("coupon_status"));
		c.setCoupontype(ct);
		return c;
	}

}
