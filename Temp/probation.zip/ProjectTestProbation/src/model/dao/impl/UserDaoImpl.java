package model.dao.impl;

import java.sql.SQLException;
import java.util.List;

import model.User;
import model.dao.UserDao;

public class UserDaoImpl extends AbstractDao implements UserDao{

	@Override
	public User getSingleUser(Integer id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public User getUserByUsername(String username) throws SQLException {
		String sql = "select * from tbl_user where user_name = ?";
		UserMapper usermapper = new UserMapper();
		Object[] parameterusername = { username };
		return getSingleObject(usermapper, sql, parameterusername);
	}

	@Override
	public List<User> getListUser(String username) throws SQLException {
		String sql = "select * from tbl_user where user_name = ?";
		UserMapper usermapper = new UserMapper();
		Object[] parameterusername = { username };
		List<User> alluser = getList(usermapper, sql, parameterusername);
		return alluser;
	}

	

}
