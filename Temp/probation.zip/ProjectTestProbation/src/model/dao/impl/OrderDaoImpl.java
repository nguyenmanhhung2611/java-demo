package model.dao.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Order;
import model.OrderDetail;
import model.dao.OrderDao;

public class OrderDaoImpl extends AbstractDao implements OrderDao {
	@Override
	public int createOrder(Order order) throws SQLException {
		String sql1 = "INSERT INTO tbl_order (coupon_id, user_id, discount ,address_info, total_payment) VALUES(?,?,?,?,?) ";
		PreparedStatement pstmt = getConnection().prepareStatement(sql1);
		Object[] params = { order.getCouponId(), order.getUserId(),
				order.getDiscount(), order.getAddressInfo(),
				order.getTotalPayment() };
		addParameters(params, pstmt);
		pstmt.executeUpdate();
		Integer orderId = getLastInsertedId();
		String sql2 = "INSERT INTO tbl_orderdetail (quantity, order_id, product_id, creation_date) VALUES (?,?,?, NOW())";
		for (OrderDetail detail : order.getItems()) {
			PreparedStatement dtPstmt = getConnection().prepareStatement(sql2);
			Object[] dtParams = { detail.getQuantity(), orderId,
					detail.getProductId() };
			addParameters(dtParams, dtPstmt);
			dtPstmt.executeUpdate();
		}
		return orderId;
	}

	

}

