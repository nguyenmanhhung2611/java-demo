package model.dao.impl;

import java.sql.SQLException;

import model.Coupon;
import model.dao.CouponDao;

public class CouponDaoImpl extends AbstractDao implements CouponDao{

	//select and inner join 2 tables coupon and coupon type
	@Override
	public Coupon getByCode(String code) throws SQLException {
		String sql = "SELECT "
				+ "tbl_coupon.id AS coupon_id, tbl_coupon.name AS coupon_name, tbl_coupon.start_date AS coupon_start_date, "
				+ "tbl_coupon.expired_date AS coupon_expired_date,tbl_coupon.coupon_type_id AS coupon_type_id, "
				+ "tbl_coupon.status AS coupon_status, tbl_coupon_type.name AS coupon_type_name, "
				+ "tbl_coupon_type.discount AS coupon_type_discount, tbl_coupon.code as coupon_code "
				+ "FROM tbl_coupon "
				+ "INNER JOIN "
				+ "tbl_coupon_type ON tbl_coupon.coupon_type_id = tbl_coupon_type.id "
				+ "WHERE tbl_coupon.code = ?";
		CouponMapper mapper = new CouponMapper();
		Object parameters[] = { code };
		return getSingleObject(mapper, sql, parameters);
	}

}
