package model.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;
import model.dao.DBMapper;

public class UserMapper implements DBMapper<User>{

	@Override
	public User doMapping(ResultSet rs) throws SQLException {
		User user = new User();
		user.setFirstname(rs.getString("first_name"));
		user.setId(rs.getInt("id"));
		user.setPassword(rs.getString("password"));
		user.setLastname(rs.getString("last_name"));
		user.setIsactive(rs.getInt("isactive"));
		user.setName(rs.getString("user_name"));
		return user;
	}

}
