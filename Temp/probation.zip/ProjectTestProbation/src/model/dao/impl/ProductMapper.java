package model.dao.impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import model.Product;
import model.dao.DBMapper;

public class ProductMapper implements DBMapper<Product> {

	@Override
	public Product doMapping(ResultSet rs) throws SQLException {
		Product p = new Product();
		p.setName(rs.getString("name"));
		p.setPrice(rs.getDouble("sale_price"));
		p.setQuantity(rs.getInt("stock_quantity"));
		p.setId(rs.getInt("id"));
		p.setLastUpdate(rs.getDate("last_update"));
		return p;
	}
	
}
