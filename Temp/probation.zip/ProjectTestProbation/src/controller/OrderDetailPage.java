package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import util.SessionHelper;
import model.Order;
import model.OrderForm;
import model.User;

/**
 * Servlet implementation class OrderDetailPage
 */
//@WebServlet("/OrderDetailPage")
public class OrderDetailPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public OrderDetailPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		HttpSession session = request.getSession();
		Order order = getSessionOrder(session);
		if (order == null) {
			response.sendRedirect("listproduct");
			return;
		}
		OrderForm orderForm = new OrderForm(order);
		User user = getSessionUser(session);
		request.setAttribute("order", orderForm);
		request.setAttribute("user", user);
		request.setAttribute("order_error", SessionHelper.readFlashMessage("order_error", session));
		request.getRequestDispatcher("orderDetail.jsp").forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	private Order getSessionOrder(HttpSession session) { 
		Object order = session.getAttribute("MY_ORDER");
		if (order != null && order instanceof Order) {
			return (Order) order;
		} else {
			return null;
		}
	}

	private User getSessionUser(HttpSession session) {
		Object user = session.getAttribute("MY_SESSION");
		if (user != null && user instanceof User) {
			return (User) user;
		} else {
			return null;
		}
	}
}
