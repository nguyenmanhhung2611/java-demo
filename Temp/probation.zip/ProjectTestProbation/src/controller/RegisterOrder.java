package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.CouponService;
import service.OrderService;
import service.impl.CouponServiceImpl;
import service.impl.OrderServiceImpl;
import sun.font.CreatedFontTracker;
import util.SessionHelper;
import model.Coupon;
import model.Order;
import model.User;
import model.dao.CouponDao;
import model.dao.OrderDao;
import model.dao.impl.CouponDaoImpl;
import model.dao.impl.OrderDaoImpl;

/**
 * Servlet implementation class RegisterOrder
 */
// @WebServlet("/RegisterOrder")
public class RegisterOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterOrder() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		Order order = getSessionOrder(session);
		String couponcode = request.getParameter("txtcoupon");
		String address = request.getParameter("txtaddress");
		CouponServiceImpl csimpl = new CouponServiceImpl();
		OrderServiceImpl odsimpl = new OrderServiceImpl();
		//RequestDispatcher rd = request.getRequestDispatcher("successfullpage.jsp");

//		if (couponcode == null || couponcode.trim().length() == 0) {
//			SessionHelper.writeFlashMessage("order_error",
//					"Please, Enter Coupon Code", session);
//			response.sendRedirect("orderdetailpage");
//			return;
//		}
		if (address ==  null || couponcode.trim().length() == 0) {
			SessionHelper.writeFlashMessage("order_error",
					"Please, Enter Adress Info", session);
			response.sendRedirect("orderdetailpage");
			return;
		}
		if (csimpl.applyCoupon(order, couponcode)) {
			order.setAddressInfo(address);
			odsimpl.saveOrder(order);
			response.sendRedirect("successfullpage.jsp");
		} else {
			SessionHelper.writeFlashMessage("order_error",
					"Can not apply coupon", session);
			response.sendRedirect("orderdetailpage");
			return;

		}
	}

	private Order getSessionOrder(HttpSession session) {
		Object order = session.getAttribute("MY_ORDER");
		if (order != null && order instanceof Order) {
			return (Order) order;
		} else {
			return null;
		}
	}

//	private User getSessionUser(HttpSession session) {
//		Object user = session.getAttribute("MY_SESSION");
//		if (user != null && user instanceof User) {
//			return (User) user;
//		} else {
//			return null;
//		}
//	}

}
