package controller;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.impl.OrderServiceImpl;
import service.impl.ProductServiceImpl;
import model.Order;
import model.Product;
import model.User;
import model.dao.impl.ProductDaoImpl;

/**
 * Servlet implementation class AddtoCard
 */
// @WebServlet("/AddtoCard")
public class AddtoCard extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddtoCard() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		Integer id = Integer.parseInt(request.getParameter("txtid"));
		Integer quantity = Integer
				.parseInt(request.getParameter("txtquantity"));

		HttpSession session = request.getSession();

		Order order = getSessionOrder(session);
		if (quantity == 0) {
			RequestDispatcher rd = request.getRequestDispatcher("listproduct");
			request.setAttribute("meg", "please insert quantity lager than 0");
			rd.forward(request, response);
		} else if (quantity > 0) {
			if (order == null) {
				order = new Order();
				order.setUserId(getSessionUser(session).getId());
			}
			try {
				Product product = new ProductServiceImpl().getSingleProduct(id);
				order.addItem(product, quantity);
				session.setAttribute("MY_ORDER", order);
				response.sendRedirect("listproduct");
			} catch (NumberFormatException n) {
				RequestDispatcher rd = request.getRequestDispatcher("listproduct");
				request.setAttribute("meg","not character, please insert a number");
				rd.forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			RequestDispatcher rd = request.getRequestDispatcher("listproduct");
			request.setAttribute("meg", "not character, please insert a number");
			rd.forward(request, response);
		}

	}

	private Order getSessionOrder(HttpSession session) {
		Object order = session.getAttribute("MY_ORDER");// create session
		if (order != null && order instanceof Order) {
			return (Order) order;
		} else {
			return null;
		}
	}

	private User getSessionUser(HttpSession session) {
		Object user = session.getAttribute("MY_SESSION");
		if (user != null && user instanceof User) {
			return (User) user;
		} else {
			return null;
		}
	}

}
