package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import service.impl.ProductServiceImpl;
import model.Product;
import model.User;
import model.dao.impl.ProductDaoImpl;

/**
 * Servlet implementation class ListProduct
 */
//@WebServlet("/ListProduct")
public class ListProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListProduct() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<Product> listpd;
		try {
			listpd = new ProductServiceImpl().getAllProducts();
			request.setAttribute("listproduct", listpd);
			request.setAttribute("user", getSessionUser(request.getSession()));
			request.getRequestDispatcher("listproduct.jsp").forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private User getSessionUser(HttpSession session) {
		Object user = session.getAttribute("MY_SESSION");
		if (user != null && user instanceof User) {
			return (User) user;
		} else {
			return null;
		}
	}

}
