package todolist;

public class ToDoList {

//	First step:
//	+ Import Database.
//	+ Create Dynamic Web Project.
//	+ Create package:
//		- db: Connection Database
//		- Controller: include servlet files. 
//		- Model: User, Product, Order, OrderDetail, Coupon, Coupon Type.
//			+ Dao: declare interface and method for user, product, order, coupon
//			+ DaoImpl: Implement all Iterface of every object
//			+ Service: declare interface and method for User, Product, Order, Coupon
//			+ ServiceImpl: Implement all Interface (call Dao). and handle business logic
	
	
	
	
	
//	1. model package 
//	- User	
//	- Product 
//	- OrderDetail
//	- Order
//	- CouponType
//	- Coupon
//	- OrderForm : Customer cart 
//	
//2. model.dao package
//	- CouponDao: get coupon code by code.
//	- DBMapper: interface mapper to tables in SQL
//	- ProductDao: get all product and get Single Product
//	- UserDao: get User by username and get list user.
//	
//3. model.dao.impl package
//	- AbstactDao: Base method to openconnection(), closeconnection(), implement get list product or single product, 
//	add parameter in query sql, auto garbage, get LAST_INSERT_ID 
// - CouponDaoImpl: Imlement Interface CouponDao ==> select coupon code by code	
// - CouponMapper: Mapping to table coupon and coupon type
// - OrderDaoImpl: Implement Interface OrderDao ==> Insert into 2 tables order and order detail
// - ProductDaoImpl: Implement Interface ProductDao ==> get list product and get single product
// - ProductMapper: Mapping to table product
// - UserDaoImpl: Implement Interface UserDao ==> Select user by name and list all user
// - UserMapper: Mapping to table user
//
//4. service package
// - CouponService: declare interface get coupon by code
// - OrderService: declare interface to create order (insert)
// - ProductService: declare interface to get list product and single product
// - UserService: declare interface to check login user, get user by name. get all user
//
//5. service.impl package
// - CouponServiceImpl: Implement interface couponservice (and call Coupon dao)
// - OrderServiceImpl: 	Implement interface orderservice (and call Order dao)
// - ProductServiceImpl: Implement interface productservice (and call product dao)
// - UserServiceImpl: Implement interface userservice (and call user dao)	
//
//6. util package
// - notification for user by flash message
//
//7.db package
// - Connection to database
// 
//8.filter package
// - login filter: say to user login before buying
//
//9. controller package
// - addtocart: 
// - listproduct: show all product in database
// - login: login handling code
// - logout: logout handling code (remove session user)
// - OrderDetail: show products and cost which user selected
// - RegisterOrder: validate and check coupon and insert to database
// - Successful: when successful payment user will move to this page

	
	
	
	
}
