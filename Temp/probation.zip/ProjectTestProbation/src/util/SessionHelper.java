package util;

import javax.servlet.http.HttpSession;

public class SessionHelper {
	public static String readFlashMessage(String messageKey, HttpSession session) {
		Object msg = session.getAttribute(messageKey);
		if (msg != null && msg instanceof String) {
			session.removeAttribute(messageKey);
			return (String) msg;
		}
		return null;
	}
	
	public static void writeFlashMessage(String messageKey, String msg, HttpSession session) {
		session.setAttribute(messageKey, msg);
	}
}
