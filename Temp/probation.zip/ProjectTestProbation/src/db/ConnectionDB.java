package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionDB {
	private String url;
	private String serverName;
	private String dbName;
	private String username;
	private String password;
	private Connection conn;

	public ConnectionDB() {
		this.url = "jdbc:mysql://";
		this.dbName = "shopproducts";
		this.serverName = "localhost";
		this.username = "root";
		this.password = "root";
	}

	private String getMyURL() {
		return url + serverName + ":3306/" + dbName;
	}

	public Connection getMyConn() throws ClassNotFoundException, SQLException {
		conn = null;

		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(getMyURL(), username, password);
		if (conn != null) {
			System.out.println("Ket noi thanh cong");
		} else {
			System.out.println("ket noi that bai");
		}
		return conn;
	}


//	public static void main(String[] args) throws ClassNotFoundException,
//			SQLException {
//		ConnectionDB con = new ConnectionDB();
//		con.getMyConn();
//		//System.out.println(con.checkLogin("abc", "123"));
//	}
}
