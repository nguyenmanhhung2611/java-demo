/**
 * 
 */
/**
 * @author thoph
 *
 */
package testcase;

import java.sql.SQLException;

import service.impl.UserServiceImpl;
import model.User;
import model.dao.UserDao;
import model.dao.impl.UserDaoImpl;

public class TestService  {

	private UserServiceImpl userserimpl = new UserServiceImpl();
	public User getUserbyName() {
		return null;
	}

	public boolean isValidate(String username) {
		if (setEmptynull(username))
			return false;
		try{
			return userserimpl.getUserByUsername(username) != null;
		}catch(SQLException ex){
			return false;
		}
	}

	public boolean isValidate(String username, String password)
			throws SQLException {
		if (setEmptynull(username))
			return false;
		else if (setEmptynull(password))
			return false;
		User user = userserimpl.checkLogin(username, password);
		return (user != null);
	}

	private boolean setEmptynull(String input) {
		if (input == null) {
			return true;
		} else if (input.length() == 0) {
			return true;
		}
		return false;
	}

}