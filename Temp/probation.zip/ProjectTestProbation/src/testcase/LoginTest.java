package testcase;

import static org.junit.Assert.assertEquals;

import java.sql.SQLException;

import org.junit.Before;
import org.junit.Test;


public class LoginTest {
	
	@Before
	public void setUp()
	{
		
	}
	
	@Test
	public void  returnfalsewhenusernull(){
		//Given
		String username = null;
		String password = "123";
		boolean action = false;
		//when
		TestService as = new TestService();
		try {
			action = as.isValidate(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Then
		assertEquals(false, action);
	}
	
	@Test
	public void returnfalsefalsewhenpasswordnull(){
		//Given
		String username = "abc";
		String password = null;
		boolean action = false;
		//when
		TestService as = new TestService();
		try {
			action = as.isValidate(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Then
		assertEquals(false, action);
	}
	
	@Test
	public void returnfalsewhenpasswordempty(){
		//Given
		String username = "abc";
		String password = "";
		boolean action = false;
		//when
		TestService as = new TestService();
		try {
			action = as.isValidate(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Then
		assertEquals(true, action);
	}
	
	
	@Test
	public void returnfalsewhenuservalid(){
		//Given
		String username = "abc";
		String password = "1234";
		boolean action = false;
		//when
		TestService as = new TestService();
		try {
			action = as.isValidate(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Then
		assertEquals(false, action);
	}
	
	@Test
	public void returnfalasewhenusernotvalid(){
		//Given
		String username = "hieu";
		String password = "123";
		boolean action = false;
		//when
		TestService as = new TestService();
		try {
			action = as.isValidate(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Then
		assertEquals(true, action);
	}
	
	@Test
	public void returnfalsewhenPassIncorrect(){
		//Given
		String username = "hieu";
		String password = "123789";
		boolean action = false;
		//when
		TestService as = new TestService();
		try {
			action = as.isValidate(username, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		//Then
		assertEquals(false, action);
	}
	
	
	
	
	
}
